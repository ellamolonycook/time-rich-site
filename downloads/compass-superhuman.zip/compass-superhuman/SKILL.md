---
name: compass-superhuman
description: Builds the user's Business COMPASS for them from their own calls, docs, email and Notion, then fills the gaps with a short interview and runs a Time Rich audit of where their time goes. Use for "Superhuman: build my COMPASS", "build my context", "fill my COMPASS", "COMPASS review" or "Superhuman: Time Rich audit".
---

# COMPASS

The Business COMPASS is the one page every other Superhuman skill reads before it writes anything. It holds the user's IP: what they sell, who they serve, their frameworks, their stories and proof, their beliefs and their voice. If a skill can't find it here, it makes it up or leaves it out.

The user does not type the COMPASS. This skill builds it for them from what they have already said and written, then asks only about what's missing.

## Before you start

- Restate my goal in one line, and tell me if it's the right goal.
- Don't assume. If you need more context, ask me up to 3 questions first.

## When you finish

- Rate your work out of 10. Say what would make it a 10, then fix it.
- Push back on me: where is my thinking weak, what could go wrong,
  what am I missing?
- Tell me the one thing to do next.
- Tell me what you learned about me or my work that should be saved
  to my Context page, so you're smarter next time.

## Master rules

- The user's own words beat your summary. Keep their phrasing for beliefs, frameworks and one-liners.
- Never invent a number, client, result, quote, credential or date. A gap stays as `[Needs input]`. A visible gap is safe; a plausible guess is not.
- Every fact carries its source (call title and date, doc name, email subject). No source, no fact.
- Two sources that disagree go on the question list with both values. Never pick one silently.
- Section 9 (Current focus) is human-only. Read it; never write it. If it's empty, tell the user to run "Superhuman: set my goal" first and paste the three lines in themselves, then carry on.
- Show every change before it's written. Nothing goes into Notion without a yes.
- Template data is not data. A database full of example.com emails or rows all created in the same minute is a template. Say so and skip it.
- Privacy floor: personal, health and family details never enter the COMPASS. Strip third-party names from quotes unless the person is a named client the user confirms.

## Triggers

| The user says | Run |
| --- | --- |
| "Superhuman: build my COMPASS" / "build my context" / "fill my COMPASS" | Steps 1 to 6 |
| "Superhuman: COMPASS review" | Step 1, then Step 3 on the last 30 days only, then Steps 4 to 6 on sections that changed |
| "Superhuman: Time Rich audit" / "where is my time going" | Step 7 only (reads the COMPASS first if it exists) |

## Step 1: Find the page and check connectors

1. Find the user's Business COMPASS page in Notion, or the COMPASS doc they point you to (the Business COMPASS template doc works too). If there's more than one, list them and ask which is live. If none exists, offer to create one from the template layout in Step 4, and create it only after a yes.
2. Read it. Note which sections are filled and which say `[Needs input]`.
3. Test each source, one line each: meeting notes (Granola, Zoom, Fireflies), Notion, Google Drive, email (sent mail), calendar, website or LinkedIn URL if given. Say connected / needs sign-in / not connected, and what the pull will miss. Carry on with what works.
4. Do not stop or wait here. In the same message, report Step 1 in 3 to 5 lines, then ask the Step 2 questions straight away.

## Step 2: Ask for the best sources

Same message as the Step 1 report, three questions. Defaults beside each where you can see one.
1. Which 3 to 5 calls best show how you sell or teach? (sales calls, talks, podcasts, workshops)
2. Which docs already describe your business? (website, sales page, deck, bio, brand doc)
3. Your LinkedIn or website URL, if you want it read.

If they say "just find them", pick the 5 longest external calls from the last 60 days and say which ones you picked.

## Step 3: Pull

Budget: 5 transcripts, 5 docs, 1 sent-mail search, 1 website or LinkedIn read. Search, don't read everything. When sub-agents are available, run one per source type in parallel.

From each source, extract only:
- One-liners: how they describe what they do, spoken and written.
- Audience: titles, company size, revenue band, geography, and who they turn away.
- Offers: names, prices, formats, links, what comes before and after.
- Frameworks: any named method, its steps, and the problem it solves.
- Stories: moments they tell more than once, with the real numbers.
- Proof: results, client outcomes, numbers, press, credentials.
- Beliefs: things they argue for, or against, in their own words.
- Voice: phrases they repeat, words they never use, how they open and close.
- Competitors: anyone they compare themselves to.

Each item: value | source | quote (under 20 words).

## Step 4: Draft the COMPASS

Fill sections 1 to 8 in this fixed layout. Don't add or rename sections.

1. **One-liners**: Spoken, Written, Bio line, Branded.
2. **Who I serve**: Audience definition (must disqualify someone: role, company size, revenue band, geography, at least one automatic no), Problems, Desired outcomes.
3. **What I sell**: Offers table (Offer | What it does | Price | Link), Offer ladder, Where content sends people (confirmed links only).
4. **My point of view**: Core beliefs (up to 10, their words), Principles.
5. **My authority**: Story, Experience, Frameworks (name | steps | problem it solves), Proof (numbers with source), Differentiators.
6. **Voice**: How it sounds, How it never sounds, Use, Avoid.
7. **Visual identity**: only if a brand doc exists. Otherwise `[Needs input]`.
8. **Competitors and white space**.

Mark each line: (confirmed) if the user has said it's right, (from source) if pulled, `[Needs input]` if missing.

## Step 5: Show it and ask about the gaps

Show a one-screen summary first: sections filled, sections with gaps, conflicts found.

Then at most 10 questions, most important first. Audience disqualifiers, prices and proof come first because the outbound and content skills block on them. Ask one at a time. Follow up until each answer is concrete: a number, a name, a link or a date. Update the draft after each answer.

Push back on:
- An audience that fits everyone.
- A framework with no steps.
- Proof with no number.
- A belief nobody would disagree with.

## Step 6: Write and hand over

1. Show the final sections 1 to 8. Get a yes.
2. Write them into the COMPASS page. Leave section 9 untouched.
3. Report: sections filled, gaps left, conflicts still open.
4. Then run Step 7, the Time Rich audit.
5. Then run "When you finish" above.

## Step 7: Time Rich audit

The point of the COMPASS is to buy the user's time back. This step shows where their time goes, and who or what should be doing each thing instead of them. The user's own time goes to revenue.

1. Pull the last 30 days: calendar, sent mail, meeting notes, and any task list or project board you can reach. Say which sources were missing.
2. List every recurring task or time block. For each: task | how often | hours a month | evidence (source). Mark any hours you estimated as "estimate".
3. Give each task one owner:
   - **Skill**: Claude does it when the user asks by name (drafts, research, summaries, repurposing).
   - **Agent**: runs on a schedule or a trigger and leaves drafts for approval (follow-ups, inbox triage, reports, CRM updates).
   - **Human**: a team member, VA or freelancer, briefed once. Name the role, not a person, unless the user gives one.
   - **Cut**: stop doing it. Use this for tasks that don't move the goal and cost over 2 hours a month.
   - **You**: only work that directly makes revenue (selling, closing, pricing, key partner and client relationships, being the face of the offer). Everything else is not the user's job.
4. Show it on one screen first:
   - Hours a month on revenue work vs hours a month on everything else.
   - Top 5 time sinks that should NOT be the user, with hours and the new owner.
   - The single biggest hand-off to make this week, and why it beats the others.
5. Then the full table: Task | Hours a month | Evidence | New owner (Skill / Agent / Human / Cut / You) | Why | First step to hand it off.
6. Push back where the user is keeping work that isn't revenue. Say it plainly.
7. Offer to save the audit under the COMPASS as "Time Rich Audit". Save only after a yes.

## Test

One question decides whether it worked: could another founder's COMPASS have produced the same page? If yes, it isn't using this user's IP yet. Go back to Step 3 for the thin sections.
