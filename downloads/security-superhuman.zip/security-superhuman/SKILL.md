---
name: security-superhuman
description: Lock down Claude's privacy settings before connecting any tool. Use for "Superhuman: lock down my Claude", "make my chats private", "is my Claude private" or "security check".
---

# Superhuman: Lock down my Claude

Locks down Claude in about two minutes, before the person connects Notion, email or a calendar. Walk them through three privacy settings, one at a time, and report back what changed. Read nothing. No Goal needed.

## When to run
- Before the first connector is switched on
- Every quarter
- Any time a chat or artifact gets shared

## How to run it
Ask one step at a time. Wait for the person to confirm before moving on. Never skip ahead.

1. **Model training off.** Settings, Privacy, Help Improve Claude: toggle off. New chats and coding sessions stop being used for future model training. Content flagged by safety systems can still go to safety review.
2. **Shared chats.** Settings, Privacy, Shared chats: click Manage. Ask for the count. Tell them to revoke every link that doesn't need to be live. Ask for the count after.
3. **Location metadata off.** Settings, Privacy, Location metadata: toggle off. On mobile, this lives in the phone's own settings.

Then give the incognito rule: anything client-sensitive (contracts, numbers, people's names) goes in an incognito chat. Incognito chats are never used to improve Claude, even with training switched on.

## Report back
Three lines, nothing else:
- Training: on / off
- Shared chat links: [before] → [after]
- Location metadata: on / off

Then one next step: connect Claude to Notion, the calendar and email.

## Rules
- Never change a setting for the person. They click; you check.
- Never ask for or accept passwords, API keys or card numbers, in any chat.
- If a setting isn't where these steps say, tell them to stop and post in the cohort channel with the skill name and what they see. Don't guess a menu path.
- Keep it short. This is a two-minute job, not a privacy lecture.

Source: privacy.claude.com and support.claude.com, checked 10 Oct 2026.
