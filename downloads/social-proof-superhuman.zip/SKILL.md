---
name: social-proof-superhuman
description: Turn one real result into short on-screen text lines that show social proof and spark curiosity, for Reels, TikToks, Shorts and carousel covers. Use when someone shares a result, a win, a number or a client outcome and says "make this on-screen text", "social proof lines", "text for my video" or "hook text for this result". Not for full captions (use a caption writer).
---

# Social Proof Lines

One real result, five lines that make people stop and want to know how.

## Input
A real result: a number, an outcome, a before and after, a client win. If no result is given, ask for one. Never invent a result or round it up.

## Steps
1. Restate the result in one plain sentence. Check the number and the timeframe with the person if either is vague.
2. Write 5 on-screen lines, 10 words maximum each. Mix these angles:
   - The number up front ("40k followers in 4 months.")
   - The before and after
   - The surprising method ("I let AI run my content.")
   - The open loop: what happened next, without saying it
   - The proof from someone else (a client, a reader)
3. Every line must be true to the result. No "guaranteed", no made-up speed or scale.
4. Mark the strongest line and say why in one sentence.

## Output
A numbered list of 5 lines, then the pick and why.

## Before you start
- Restate the goal in one line and say whether it is the right goal.
- Do not assume. If context is missing (audience, platform, offer), ask up to 3 questions first.

## When you finish
- Rate the work out of 10. Say what would make it a 10, then fix it.
- Push back: where is the thinking weak, what could go wrong, what is missing?
- Name the one thing to do next.
- Say what you learned that should be saved to the Context page.
