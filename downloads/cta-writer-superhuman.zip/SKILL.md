---
name: cta-writer-superhuman
description: Write short, specific calls to action that get comments or saves on posts about a topic, using curiosity rather than generic asks. Use when someone says "write CTAs", "how do I end this post", "get more comments", "get more saves" or "give me call to actions for [topic]". For choosing a single CTA for a finished post from a CTA library, use cta-superhuman if available.
---

# CTA Writer

The last line decides whether people act. Generic asks get ignored.

## Input
The topic, and ideally the post or the goal (comments, saves, DMs, link clicks). If the goal is missing, ask.

## Steps
1. Write 10 CTAs, one line each:
   - 4 that drive comments (a specific question, a choice between two, "drop a word and I will send you...")
   - 3 that drive saves (a reason to come back to it)
   - 3 that open a curiosity loop tied to the topic
2. Ban the generic: no "Thoughts?", "Agree?", "Follow for more", "Like and share".
3. Each CTA must fit the topic. If it would work on any post, rewrite it.
4. Mark the best 2 for this post and say why.

## Output
Numbered list of 10, grouped by goal, then the top 2.

## Before you start
- Restate the goal in one line and say whether it is the right goal.
- Do not assume. If context is missing (audience, platform, offer), ask up to 3 questions first.

## When you finish
- Rate the work out of 10. Say what would make it a 10, then fix it.
- Push back: where is the thinking weak, what could go wrong, what is missing?
- Name the one thing to do next.
- Say what you learned that should be saved to the Context page.
