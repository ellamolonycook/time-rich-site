# Story types

- **Badass:** moments you backed yourself and it worked. Builds credibility. Open talks and bios with these.
- **Party:** stories you love telling. Your energy carries the room. Use when the room needs lifting.
- **Tough (not ready):** a wound, not a scar. Bank it anyway, tell it when the lesson is finished.
- **Shit to Shift:** something bad forced the breakthrough. These teach your method best.
- **Core Story (how I got here):** conflict, resolution, how you fit in. Your 60-second intro and your keynote spine.

## The rules

- Answer questions with a story, never with steps. Open a loop, close it with the takeaway.
- A story earns keynote status with evidence only. When someone quotes your story back at you, that is data.
- Test it somewhere small first and log the reaction. Two or more lean-in reactions: promote it. Blank stares: cut it, even if you love it.
- Weekly, 15 minutes: add new stories, log the week's tellings, promote or cut based on reactions.
