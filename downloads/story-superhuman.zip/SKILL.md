---
name: story-superhuman
description: "Pull real stories out of a person's own material (call transcripts, Granola or AI note-taker notes, voice notes, podcasts, posts, newsletters) and bank them in the Story Bank format: name, one-line hook, type, takeaway, the question it answers, conflict, resolution and how they fit in. Use when someone says \"find my stories\", \"mine my calls for stories\", \"build my story bank\", \"what stories have I told\", \"story audit\", or shares a transcript and wants stories from it. Also finds stories they keep telling and pairs each with the questions they get asked. Not for writing a post from a story (use a post writer) or interviewing someone from scratch (use linkedin-interviewer)."
---

# Story Superhuman

Frameworks get forgotten. Stories get remembered, shared and booked.

Most people already tell great stories, in calls, voice notes and podcasts, then lose them. This skill finds them in what the person has already said, and banks each one so it can be used again on stage, in posts and in sales calls.

## The one rule

**Never invent.** Every story, number, name and quote must come from the source material. If a detail is missing, leave the field blank and ask. A made-up detail in someone's own story destroys trust the moment they tell it.

## Before you start

- Restate the goal in one line and say whether it's the right goal.
- Don't assume. If you need context (who the audience is, which sources to search), ask up to 3 questions first.

## Step 1: Gather the material

Use what the person gives you, or search their connected sources: Granola or AI note-taker transcripts, voice notes, podcast transcripts, LinkedIn posts, newsletters, Google Drive. Default window: the last 90 days. Say which sources you searched and which weren't connected, in one line.

## Step 2: Find the stories

A story is **one specific moment** with a before, a turning point and an after. A summary of a career is not a story. An opinion is not a story.

Look for:
- Moments with a date, a place, a person or a number ("that Monday", "in London", "$300k")
- Lines like "I'll never forget", "the moment I realised", "nobody believed", "I nearly quit"
- Stories they tell more than once across different calls. Repetition means it works, so flag it.
- Moments where a listener reacted (laughed, asked a follow-up, said "wow")

Ignore anything confidential about clients, deals or other people's private lives. List it under "Held back" with one line on why.

## Step 3: Bank each story

One row per story, in these columns:

| Column | How to fill it |
|---|---|
| Story Name | 3 to 8 words, memorable, in their language |
| The Hook (one line) | The opening line they'd say out loud. Use their words where possible. |
| Type | One of: Badass, Party, Tough (not ready), Shit to Shift, Core Story (how I got here). See references/story-types.md |
| Status | Banked (complete), Testing (told once, unproven) or Needs detail (gaps to fill) |
| Takeaway (what it teaches) | One line. No takeaway means it isn't usable yet: set Status to Needs detail. |
| Question it answers | The question a listener asks that this story answers |
| Conflict | What was at stake, and what made it hard |
| Resolution | What happened, with the specific result |
| How I fit in / offer | Why this story is theirs, and how it connects to what they do |
| Times told | How many times it appears in the sources |
| Where it landed best | Only if the source shows a reaction |
| Audience evidence | Quote what the listener said or did. Blank if none. |
| Next place to tell it | Keynote opener, LinkedIn post, podcast, webinar, sales call, panel |
| Source | Link or file name, with timestamp |

**Tough stories:** if it's a wound, not a scar (unresolved, raw, or involves other people's privacy), set Type to Tough (not ready) and Next place to "Hold. Revisit later". Never suggest telling it publicly yet.

## Step 4: Link stories to questions

Build a short table: Question I get asked | Go-to story | Takeaway I land | Backup story. Use real questions from the transcripts where possible.

## Step 5: Save

If their Story Bank sheet is connected, add new rows to the "Story Bank" tab. Check existing rows first. If a story is already there, update Times told and Audience evidence instead of adding a duplicate. Never delete or rewrite their existing rows. If no sheet is connected, give the rows as a table they can paste.

## Output

1. The new story rows (table first, no intro)
2. Question links
3. Needs detail: for each, one question to ask them to complete it
4. Held back: confidential or not ready, one line each

## When you finish

- Rate the work out of 10. Say what would make it a 10, then fix it.
- Push back: which stories are weaker than they think, what's missing, what could go wrong if they tell one too early.
- Name the one story to tell next, and where.
- Say what you learned about them that should be saved to their Context page.
